<div class="container-fluid">
	<div class="card shadow mb-4">
		<h6 class="card-header d-flex justify-content-between align-items-center font-weight-bold text-primary">
			404
		</h6>
		<div class="card-body">
			<img style=" display: block;margin-left: auto;margin-right: auto;width: 50%;" src="<?php echo base_url('public/AtlantisLite/img/core/404.png');?>" class="img-responsive" alt="error 403">
		</div>
	</div>
</div>